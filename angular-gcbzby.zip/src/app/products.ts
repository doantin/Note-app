export interface Product {
  id: number;
  name: string;

  description: string;
}

export const products = [
  {
    id: 1,
    name: 'Eating',

    description: 'Eat a bread in the morning',
  },
  {
    id: 2,
    name: 'Go to work',

    description: 'Go to work in com pany',
  },
  {
    id: 3,
    name: 'Fo home',

    description: 'Go home',
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
